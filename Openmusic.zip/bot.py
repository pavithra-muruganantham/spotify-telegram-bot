from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

# --- Replace with your keys ---
TELEGRAM_TOKEN = "7192762256:AAHFDc6IyTQehcr4eGXmskxKLJ5qB_5PmWo"
SPOTIFY_CLIENT_ID = "853aa02a224e4888a57fbd93e34d67ee"
SPOTIFY_CLIENT_SECRET = "222d94b9ff1b4c43ae1e928c4f6ee886"

# Spotify setup
spotify_auth = SpotifyClientCredentials(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET
)
sp = spotipy.Spotify(auth_manager=spotify_auth)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hi! Send /song followed by a track name to get a Spotify preview.")

async def song(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = ' '.join(context.args)
    if not query:
        await update.message.reply_text("Please provide a song title. Example: /song Shape of You")
        return

    results = sp.search(q=query, type='track', limit=1)
    try:
        track = results['tracks']['items'][0]
        title = track['name']
        artist = track['artists'][0]['name']
        url = track['external_urls']['spotify']
        preview = track['preview_url']

        message = f"**{title}** by *{artist}*\n[Open in Spotify]({url})"
        if preview:
            message += f"\n[Preview 30s]({preview})"
        else:
            message += "\nNo preview available."

        await update.message.reply_text(message, parse_mode="Markdown", disable_web_page_preview=False)

    except IndexError:
        await update.message.reply_text("No results found. Try a different title.")

# Bot Setup
app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("song", song))
app.run_polling()
